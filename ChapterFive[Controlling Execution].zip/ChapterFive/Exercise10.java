import java.util.ArrayList;

public class Exercise10 {
    static void print(String string) {
        System.out.println(string);
    }

    static int factorial(int number) {
        int factorial = 1;
        for (int i = 1; i <= number; i++) {
            factorial *= i;
        }
        return factorial;
    }

    static void printVampire(int number) {
        ArrayList<String> list = new ArrayList<>();

        for (String s : Integer.toString(number).split("")) {
            list.add(s);
        }

        int length = list.size();

        int combination = (factorial(length) / (factorial(2) * (factorial(length - 2))));

     final    int i1 = 0;

        for (int i = 0; i < combination; i++) {
            for (int j = 0; j < length; j++) {

                String s = list.get(j) + list.get(j + 1);
                print(s);
                System.out.println(s.equals(null));
                final int i2 = Integer.getInteger(list.get(j + 2) + list.get(j + 3));
                print("" + i1);
                print("" + i2);
                if (i1 * i2 == number) {

                    break;
                }
            }
        }

        // for (char c : cs) {
        // list.add(c)
        // }

    }

    public static void main(String[] args) {
        printVampire(1234);
    }
}
