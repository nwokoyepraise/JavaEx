
/**
 * This class solves Exercise 1 Chapter 5 ["Controlling Execution"] of the book "Thinking
 * in
 * Java"
 * This program prints values from 1 to 100
 * 
 * @author nwokoyepraise@gmail.com
 */
public class Exercise1 {

    public static void main(String[] args) {
        for (int i = 1; i <= 100; i++) {
            System.out.println(i);
        }
    }
}