/**
 * This class solves Exercise 24 Chapter 11 ["Inner Classes"] of the
 * book "Thinking in Java"
 * This exercise involves adding more inner classes in GreenhouseControls.java and modifying GreenhouseController.java to handle it
 * 
 * @author nwokoyepraise@gmail.com
 */
public class Exercise24 {
    
    public static void main(String[] args) {
        GreenhouseController.main(args);
    }
}
