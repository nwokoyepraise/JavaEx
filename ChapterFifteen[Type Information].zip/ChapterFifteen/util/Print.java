package util;

public class Print {
    public Print(Object arg) {
        System.out.println(arg);
    }

    public static void print (Object arg) {
        System.out.println(arg);
    }
}
