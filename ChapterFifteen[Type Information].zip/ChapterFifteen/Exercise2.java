
/**
 * This class solves Exercise 2 Chapter 15 ["Type Information"] of the
 * book "Thinking in Java"
 * This exercise dhas to deal with adding a new interface ("Moves") in typeinfo/toys.FancyToy and ensuring that it is displayed properly
 * 
 * @author nwokoyepraise@gmail.com
 */
import typeinfo.toys.*;

public class Exercise2 {

    public static void main(String[] args) {
        ToyTest.main(args);
    }
}