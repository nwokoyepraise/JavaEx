/**
 * This class solves Exercise 28 Chapter 13 ["Error Handling with Exceptions"] of the
 * book "Thinking in Java"
 * This exercise has to deal with modifiying exercise 4 to extend from the RuntimeException class
 * 
 * @author nwokoyepraise@gmail.com
 */
public class Exercise28 {
    
    public static void main(String[] args) {
        Exercise4.main(args);
    }
}
