public class Exercise30 {
    /**
 * This class solves Exercise 31 Chapter 13 ["Error Handling with Exceptions"] of the
 * book "Thinking in Java"
 * This exercise demonstrates throwing without catching immediately by offloading it to another method
 * 
 * @author nwokoyepraise@gmail.com
 */
    public static void main(String[] args) {
        Human.main(args);
    }
}
