/**
 * This class solves Exercise 2 Chapter 10 ["Interfaces"] of the
 * book "Thinking in Java"
 * This exercise verifies that one can't create an instance of an abstract class
 * 
 * @author nwokoyepraise@gmail.com
 */
public class Exercise2 {
    public static void main(String[] args) {
       // Food f = new Food(); create create an instance of abstract class
    }
}


abstract class Food {

}