package util;

public class Print {
    
    public static void print(Object arg){
        System.out.println(arg);
    }
}
