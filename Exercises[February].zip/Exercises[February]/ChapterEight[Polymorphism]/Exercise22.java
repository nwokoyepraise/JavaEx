/**
 * This class solves Exercise 23 Chapter 8 ["Reusing Classes"] of the
 * book "Thinking in Java"
 * The class demonstrates what happens when an attempt is made to inherit a final class
 * An error occurs stating that the class cannot be subclassed
 * 
 * @author nwokoyepraise@gmail.com
 */

public class Exercise22 extends Book {
    
    public static void main(String[] args) {
        
    }
}

final class Book {}
