import static java.lang.System.out;
/**
 * This class solves Exercise 1 Chapter 4 ["Operators"] of the book "Thinking in Java"
 * @author nwokoyepraisea@gmail.com
 */
public class Exercise1 {
    public static void main(String[] args) {
        out.println("Printing with short form of print statement");
        System.out.println("Printing with long form print statement");
    }

}
