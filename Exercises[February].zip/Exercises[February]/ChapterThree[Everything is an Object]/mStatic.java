public class mStatic {
static int i = 5;
int j = 10;
}