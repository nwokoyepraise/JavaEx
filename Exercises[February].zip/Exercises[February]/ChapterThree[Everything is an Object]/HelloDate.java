/**
 * This class solves Excercise 2 Chapter 3 [Topic: "Everything is an Object"] of
 * the book "Thinking in Java"
 * 
 * @author nwokoyepraise@gmail.com
 */
public class HelloDate {
    /** Main method comment documentation */
    public static void main(String[] args) {
        System.out.println("hello world");
    }
}
