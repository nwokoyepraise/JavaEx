/**
 * This class solves Excercise 14 Chapter 3 [Topic: "Everything is an Object"]
 * of the book "Thinking in Java"
 * 
 * @author nwokoyepraise@gmail.com
 *
 *         <ol>
 *         <li>First item
 *         <li>Second item
 *         <li>Third item
 *         </ol>
 */
public class Documentation1 {
    /** A field comment */
    public int i;

    /** A method comment */
    public void f() {
    }
}
