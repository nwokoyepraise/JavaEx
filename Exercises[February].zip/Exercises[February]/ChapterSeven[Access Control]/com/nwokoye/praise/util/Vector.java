package com.nwokoye.praise.util;

public class Vector {
    
}
