import access.Widget;

public class Exercise7 {
    
    public static void main(String[] args) {
        new Widget();
    }
}
