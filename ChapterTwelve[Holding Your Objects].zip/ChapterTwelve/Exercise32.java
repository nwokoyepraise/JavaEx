

public class Exercise32 {

    public static void main(String[] args) {

    }
}

