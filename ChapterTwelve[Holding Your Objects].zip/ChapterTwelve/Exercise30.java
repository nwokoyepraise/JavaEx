/**
 * This class solves Exercise 30 Chapter 12 ["Holding Your Objects"] of the
 * book "Thinking in Java"
 * This exercise deals with implementing Collection interface in COllectionSequence.java class instead of extending  AbstractionCollection class
 * 
 * @author nwokoyepraise@gmail.com
 */
public class Exercise30 {
    
    public static void main(String[] args) {
        CollectionSequence.main(args);
    }
}
