
/**
 * This class solves Exercise 2 Chapter 7 ["Access Control"] of the
 * book "Thinking in Java"
 * This exercise proves and verifies that class collisions do occur
 * 
 * @author nwokoyepraise@gmail.com
 */
//import java.util.Vector;
import com.nwokoye.praise.util.Vector;

public class Exercise2 {
    public static void main(String[] args) {
        new Vector();
    }
}
