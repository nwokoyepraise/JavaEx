// import java.util.*;
import static util.Print.print;

public class App {

    public static void main(String[] args) {
        String mango = "mango";
        String s = "abc" + mango + "def" + 47;
        System.out.println(s);

       
        System.out.format("Row 1: [%d %f]%n", 12, 3.333);
        print(new App().getClass().getName());
    }
}