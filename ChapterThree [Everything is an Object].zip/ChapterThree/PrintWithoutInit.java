/**
 * This class solves Excercise 1 Chapter 3 [Topic: "Everything is an Object"] of
 * the book "Thinking in Java"
 * 
 * @author nwokoyepraise@gmail.com
 */
public class PrintWithoutInit {
    static int mInt;
    static char mChar;

    public static void main(String[] args) {

        System.out.println(mInt);
        System.out.println(mChar);
    }
}
